package com.assistgoat

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

class GestureController(
    private val service: AccessibilityService,
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "GestureController"
        private const val STROKE_DURATION_BASE = 350L
        private const val STROKE_DURATION_VARIANCE = 40L
        private const val MIN_STROKE_DURATION = 150L
        private const val MAX_STROKE_DURATION = 600L
        private const val PIXEL_NOISE = 3
        private const val PLAYER_Y_RATIO = 0.82f
        private const val MIN_MOVE_DISTANCE = 8
        private const val IDLE_MICRO_MOVE_CHANCE = 0.3
        private const val IDLE_MICRO_MOVE_RANGE = 5
    }

    private val playerY: Float = screenHeight * PLAYER_Y_RATIO
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var isActive = false
    @Volatile private var isEmergencyStopped = false

    private var currentX: Float = screenWidth / 2f
    private var targetX: Float = screenWidth / 2f
    private var isTouching: Boolean = false
    private var idleRunnable: Runnable? = null
    private var isGestureInProgress: Boolean = false
    private var pendingMove: Pair<Int, Long>? = null

    fun start() {
        isActive = true
        isEmergencyStopped = false
        isTouching = false
        isGestureInProgress = false
        currentX = screenWidth / 2f
        targetX = currentX
    }

    fun stop() {
        isActive = false
        cancelIdleMovement()
        isTouching = false
        isGestureInProgress = false
        pendingMove = null
    }

    fun emergencyKill() {
        isEmergencyStopped = true
        isActive = false
        cancelIdleMovement()
        isTouching = false
        isGestureInProgress = false
        pendingMove = null
    }

    fun moveTo(targetX: Int, urgencyMs: Long = 250L) {
        if (!isActive || isEmergencyStopped) return

        val clampedTarget = targetX.toFloat().coerceIn(40f, (screenWidth - 40).toFloat())
        val distance = abs(clampedTarget - currentX)

        if (distance < MIN_MOVE_DISTANCE) {
            scheduleIdleMicroMove()
            return
        }

        cancelIdleMovement()
        this.targetX = clampedTarget

        if (isGestureInProgress) {
            pendingMove = clampedTarget.toInt() to urgencyMs
            return
        }

        dispatchMove(clampedTarget, urgencyMs)
    }

    private fun dispatchMove(toX: Float, urgencyMs: Long) {
        if (!isTouching) {
            startNewTouch(toX, urgencyMs)
        } else {
            continueExistingTouch(toX, urgencyMs)
        }
    }

    private fun startNewTouch(toX: Float, urgencyMs: Long) {
        val path = buildBezierPath(currentX, playerY, toX, playerY)
        val duration = calculateDuration(abs(toX - currentX), urgencyMs)

        val stroke = GestureDescription.StrokeDescription(
            path, 0, duration, true
        )

        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        isTouching = true
        isGestureInProgress = true

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                currentX = toX
                isGestureInProgress = false
                processPendingMove()
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                isTouching = false
                isGestureInProgress = false
            }
        }, null)
    }

    private fun continueExistingTouch(toX: Float, urgencyMs: Long) {
        val path = buildBezierPath(currentX, playerY, toX, playerY)
        val duration = calculateDuration(abs(toX - currentX), urgencyMs)

        val stroke = GestureDescription.StrokeDescription.continueStroke(
            path, 0, duration, true
        )

        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        isGestureInProgress = true

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                currentX = toX
                isGestureInProgress = false
                processPendingMove()
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                isTouching = false
                isGestureInProgress = false
            }
        }, null)
    }

    private fun processPendingMove() {
        if (!isActive || isEmergencyStopped) return
        val pending = pendingMove ?: return
        pendingMove = null

        val distance = abs(pending.first.toFloat() - currentX)
        if (distance >= MIN_MOVE_DISTANCE) {
            dispatchMove(pending.first.toFloat(), pending.second)
        }
    }

    private fun buildBezierPath(fromX: Float, fromY: Float, toX: Float, toY: Float): Path {
        val path = Path()
        val noisyFromX = fromX + Random.nextInt(-PIXEL_NOISE, PIXEL_NOISE + 1)
        val noisyToX = toX + Random.nextInt(-PIXEL_NOISE, PIXEL_NOISE + 1)
        val noisyFromY = fromY + Random.nextInt(-2, 3)
        val noisyToY = toY + Random.nextInt(-2, 3)

        path.moveTo(noisyFromX, noisyFromY)

        val midX = (noisyFromX + noisyToX) / 2
        val midY = (noisyFromY + noisyToY) / 2
        val curveAmount = Random.nextInt(-15, 16).toFloat()
        val controlX = midX + (curveAmount * 0.3f)
        val controlY = midY + curveAmount

        path.quadTo(controlX, controlY, noisyToX, noisyToY)
        return path
    }

    private fun calculateDuration(distance: Float, urgencyMs: Long): Long {
        val base = when {
            distance < 50 -> urgencyMs.coerceAtLeast(MIN_STROKE_DURATION)
            distance < 200 -> STROKE_DURATION_BASE
            else -> min(STROKE_DURATION_BASE + (distance / 3).toLong(), MAX_STROKE_DURATION)
        }
        val variance = Random.nextLong(-STROKE_DURATION_VARIANCE, STROKE_DURATION_VARIANCE + 1)
        return base.coerceIn(MIN_STROKE_DURATION, MAX_STROKE_DURATION) + variance
    }

    private fun scheduleIdleMicroMove() {
        if (idleRunnable != null || !isActive || isEmergencyStopped) return
        if (!isTouching) return

        idleRunnable = object : Runnable {
            override fun run() {
                if (!isActive || isEmergencyStopped || !isTouching) return

                if (Random.nextFloat() < IDLE_MICRO_MOVE_CHANCE && !isGestureInProgress) {
                    val microOffset = Random.nextInt(-IDLE_MICRO_MOVE_RANGE, IDLE_MICRO_MOVE_RANGE + 1)
                    val microX = currentX + microOffset
                    val clamped = microX.coerceIn(40f, (screenWidth - 40).toFloat())

                    val path = buildBezierPath(currentX, playerY, clamped, playerY)
                    val duration = 100L + Random.nextLong(0, 50)
                    val stroke = GestureDescription.StrokeDescription.continueStroke(
                        path, 0, duration, true
                    )
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    service.dispatchGesture(gesture, null, null)
                    currentX = clamped
                }

                if (isActive && !isEmergencyStopped) {
                    idleRunnable?.let { handler.postDelayed(it, 500L + Random.nextLong(0, 1000)) }
                }
            }
        }
        handler.postDelayed(idleRunnable!!, 500L + Random.nextLong(0, 500))
    }

    private fun cancelIdleMovement() {
        idleRunnable?.let { handler.removeCallbacks(it) }
        idleRunnable = null
    }

    fun getCurrentX(): Int = currentX.toInt()
    fun isTouchActive(): Boolean = isTouching && isActive && !isEmergencyStopped
}
