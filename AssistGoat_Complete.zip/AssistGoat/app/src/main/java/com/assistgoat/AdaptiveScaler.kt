package com.assistgoat

import android.util.Log

class AdaptiveScaler(
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "AdaptiveScaler"
        private const val TARGET_FRAME_TIME_MS = 80L
        private const val MAX_FRAME_TIME_MS = 150L
        private const val CRITICAL_FRAME_TIME_MS = 200L
    }

    private var currentScore: Int = 0
    private val frameTimes = mutableListOf<Long>()
    private val MAX_FRAME_HISTORY = 20

    var scanTopRatio: Float = 0.60f
        private set
    var targetFps: Float = 12f
        private set
    var frameSkipRate: Int = 0
        private set
    var scanStep: Int = 4

    private var frameCount = 0

    fun recordFrameTime(timeMs: Long) {
        frameTimes.add(timeMs)
        if (frameTimes.size > MAX_FRAME_HISTORY) {
            frameTimes.removeAt(0)
        }
        frameCount++

        if (frameCount % 10 == 0) {
            updateAdaptiveSettings()
        }
    }

    fun updateScore(newScore: Int) {
        currentScore = newScore
        updateScanWindow()
    }

    private fun updateScanWindow() {
        scanTopRatio = when {
            currentScore < 5 -> 0.60f
            currentScore < 10 -> 0.50f
            currentScore < 20 -> 0.40f
            currentScore < 35 -> 0.35f
            else -> 0.30f
        }
    }

    private fun updateAdaptiveSettings() {
        if (frameTimes.isEmpty()) return

        val avgFrameTime = frameTimes.average()
        val maxFrameTime = frameTimes.maxOrNull() ?: 0L

        when {
            maxFrameTime > CRITICAL_FRAME_TIME_MS -> {
                targetFps = 6f
                frameSkipRate = 2
                scanStep = 6
            }
            maxFrameTime > MAX_FRAME_TIME_MS -> {
                targetFps = 8f
                frameSkipRate = 1
                scanStep = 5
            }
            avgFrameTime > TARGET_FRAME_TIME_MS -> {
                targetFps = 10f
                frameSkipRate = 0
                scanStep = 5
            }
            else -> {
                targetFps = 12f
                frameSkipRate = 0
                scanStep = 4
            }
        }
    }

    fun shouldSkipFrame(): Boolean {
        if (frameSkipRate == 0) return false
        return frameCount % (frameSkipRate + 1) != 0
    }

    fun getFrameIntervalMs(): Long {
        return (1000f / targetFps).toLong()
    }

    fun forceThrottle() {
        targetFps = 6f
        frameSkipRate = 2
        scanStep = 6
    }

    fun reset() {
        currentScore = 0
        frameCount = 0
        frameTimes.clear()
        scanTopRatio = 0.60f
        targetFps = 12f
        frameSkipRate = 0
        scanStep = 4
    }
}
