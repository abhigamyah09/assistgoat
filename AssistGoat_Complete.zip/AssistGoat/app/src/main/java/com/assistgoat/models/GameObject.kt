package com.assistgoat.models

import android.graphics.Rect

data class GameObject(
    val type: ObjectType,
    val boundingBox: Rect,
    val centerX: Int,
    val centerY: Int,
    val width: Int,
    val height: Int,
    val confidence: Float = 1.0f,
    val trackedId: Int = -1
)

enum class ObjectType {
    METEOR,
    UFO,
    PHONE,
    STAR,
    PLAYER,
    UNKNOWN
}

enum class ThreatPriority {
    CRITICAL,
    HIGH,
    MEDIUM,
    LOW,
    SAFE
}

data class Trajectory(
    val objectId: Int,
    val velocityX: Float,
    val velocityY: Float,
    val predictedLandingX: Int,
    val confidence: Float,
    val willHitPlayer: Boolean
)

data class MovementDecision(
    val targetX: Int,
    val priority: ThreatPriority,
    val reason: String,
    val isCollecting: Boolean = false,
    val urgencyMs: Long = 300
)
