package com.assistgoat

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkAndStart()
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            launchService(result.data!!)
        } else {
            tvStatus.text = "Status: Screen capture denied"
            Toast.makeText(this, "Screen capture permission required!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        tvStatus = findViewById(R.id.tvStatus)

        btnStart.setOnClickListener { checkAndStart() }
        btnStop.setOnClickListener { stopService() }
    }

    override fun onResume() {
        super.onResume()
        btnStop.visibility = if (isServiceEnabled()) Button.VISIBLE else Button.GONE
    }

    private fun checkAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            tvStatus.text = "Status: Need Overlay Permission"
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
            return
        }

        if (!isServiceEnabled()) {
            tvStatus.text = "Status: Enable Accessibility Service"
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Enable AssistGoat in Accessibility", Toast.LENGTH_LONG).show()
            return
        }

        tvStatus.text = "Status: Requesting Screen Capture..."
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as android.media.projection.MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun isServiceEnabled(): Boolean {
        val serviceName = "$packageName/.AssistGoatService"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(serviceName)
    }

    private fun launchService(data: Intent) {
        val intent = Intent(this, AssistGoatService::class.java).apply {
            action = "ACTION_START"
            putExtra("screenCaptureData", data)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        tvStatus.text = "Status: AssistGoat is RUNNING"
        btnStart.visibility = Button.GONE
        btnStop.visibility = Button.VISIBLE
        Toast.makeText(this, "AssistGoat Started! Open your game.", Toast.LENGTH_SHORT).show()
    }

    private fun stopService() {
        val intent = Intent(this, AssistGoatService::class.java).apply {
            action = "ACTION_STOP"
        }
        stopService(intent)

        tvStatus.text = "Status: Stopped"
        btnStart.visibility = Button.VISIBLE
        btnStop.visibility = Button.GONE
        Toast.makeText(this, "AssistGoat Stopped", Toast.LENGTH_SHORT).show()
    }
}
