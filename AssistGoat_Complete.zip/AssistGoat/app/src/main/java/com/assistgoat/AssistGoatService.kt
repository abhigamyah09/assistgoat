package com.assistgoat

import android.accessibilityservice.AccessibilityService
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import com.assistgoat.models.Trajectory
import kotlinx.coroutines.*
import java.nio.ByteBuffer

class AssistGoatService : AccessibilityService() {

    companion object {
        private const val TAG = "AssistGoatService"
        private const val CHANNEL_ID = "assistgoat_channel"
        private const val FOREGROUND_NOTIFY_ID = 1002
        private const val CAPTURE_WIDTH = 360
        private const val CAPTURE_HEIGHT = 800
        private const val RAM_SHUTDOWN_MB = 80L
        private const val RAM_WARNING_MB = 150L
    }

    private var screenWidth = 720
    private var screenHeight = 1280
    private var densityDpi = 320

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var detectionEngine: DetectionEngine? = null
    private var objectTracker: ObjectTracker? = null
    private var trajectoryPredictor: TrajectoryPredictor? = null
    private var decisionEngine: DecisionEngine? = null
    private var gestureController: GestureController? = null
    private var adaptiveScaler: AdaptiveScaler? = null
    private var overlayManager: OverlayManager? = null

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var isProcessing = false
    @Volatile private var isPaused = false
    @Volatile private var isKilled = false
    private var lastObjectsHash = 0
    private var pauseCounter = 0
    private var frameCount = 0

    private val ramMonitorHandler = Handler(Looper.getMainLooper())
    private var ramMonitorRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()

        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Log.e(TAG, "CRASH in ${t.name}: ${e.message}", e)
            emergencyShutdown("Crash: ${e.message}")
        }

        val displayMetrics = DisplayMetrics()
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        screenWidth = displayMetrics.widthPixels
        screenHeight = displayMetrics.heightPixels
        densityDpi = displayMetrics.densityDpi

        detectionEngine = DetectionEngine(screenWidth, screenHeight, scanStep = 4)
        objectTracker = ObjectTracker()
        trajectoryPredictor = TrajectoryPredictor(screenWidth, screenHeight)
        decisionEngine = DecisionEngine(screenWidth, screenHeight)
        gestureController = GestureController(this, screenWidth, screenHeight)
        adaptiveScaler = AdaptiveScaler(screenWidth, screenHeight)

        startForegroundNotification()
        startRamMonitor()

        overlayManager = OverlayManager(this) { active ->
            isPaused = !active
        }
        overlayManager?.show()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            "ACTION_START" -> {
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>("screenCaptureData")
                if (data != null) {
                    startScreenCapture(data)
                }
            }
            "ACTION_STOP" -> {
                stopAssistGoat()
            }
        }

        return START_STICKY
    }

    private fun startScreenCapture(data: Intent) {
        val mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        try {
            mediaProjection = mediaProjectionManager.getMediaProjection(RESULT_OK, data)
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    cleanup()
                }
            }, Handler(Looper.getMainLooper()))

            imageReader = ImageReader.newInstance(
                CAPTURE_WIDTH, CAPTURE_HEIGHT,
                PixelFormat.RGBA_8888, 2
            )

            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "AssistGoat",
                CAPTURE_WIDTH, CAPTURE_HEIGHT, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, Handler(Looper.getMainLooper())
            )

            gestureController?.start()
            startProcessingLoop()

        } catch (e: Exception) {
            Log.e(TAG, "Screen capture failed: ${e.message}", e)
            stopSelf()
        }
    }

    private fun startProcessingLoop() {
        scope.launch {
            isProcessing = true

            while (isProcessing && !isPaused && !isKilled) {
                val frameStart = System.currentTimeMillis()

                if (!checkRamSafety()) {
                    emergencyShutdown("Low RAM")
                    break
                }

                if (adaptiveScaler?.shouldSkipFrame() == true) {
                    delay(adaptiveScaler?.getFrameIntervalMs() ?: 83L)
                    continue
                }

                try {
                    processCurrentFrame()
                } catch (e: OutOfMemoryError) {
                    emergencyShutdown("Out of Memory")
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Frame error: ${e.message}")
                }

                val frameTime = System.currentTimeMillis() - frameStart
                adaptiveScaler?.recordFrameTime(frameTime)

                val targetInterval = adaptiveScaler?.getFrameIntervalMs() ?: 83L
                val remainingDelay = targetInterval - frameTime
                if (remainingDelay > 0) {
                    delay(remainingDelay)
                }
            }
        }
    }

    private fun processCurrentFrame() {
        val reader = imageReader ?: return
        val detection = detectionEngine ?: return
        val tracker = objectTracker ?: return
        val predictor = trajectoryPredictor ?: return
        val decider = decisionEngine ?: return
        val gesture = gestureController ?: return

        val image: Image? = reader.acquireLatestImage()
        if (image == null) return

        try {
            val bitmap = imageToBitmap(image, CAPTURE_WIDTH, CAPTURE_HEIGHT)
            if (bitmap == null) return

            detection.scanStep = adaptiveScaler?.scanStep ?: 4
            detection.scanTopRatio = adaptiveScaler?.scanTopRatio ?: 0.60f

            val detectedObjects = detection.detectFrame(bitmap)
            bitmap.recycle()

            val timestamp = System.currentTimeMillis()
            val trackedObjects = tracker.updateFrame(detectedObjects, timestamp)

            predictor.playerCenterX = decider.getPlayerX()

            val ufoTrajectories = mutableMapOf<Int, Trajectory>()
            for (ufo in tracker.getActiveUFOs()) {
                val history = tracker.getPositionHistory(ufo)
                if (history.size >= 3) {
                    val trajectory = predictor.predictTrajectory(history)
                    if (trajectory != null) {
                        ufoTrajectories[ufo.id] = trajectory.copy(objectId = ufo.id)
                    }
                }
            }

            val currentHash = trackedObjects.hashCode()
            if (currentHash == lastObjectsHash) {
                pauseCounter++
                if (pauseCounter >= 20) {
                    overlayManager?.updateStatus(getString(R.string.status_paused))
                    return
                }
            } else {
                pauseCounter = 0
                lastObjectsHash = currentHash
            }

            val currentFps = adaptiveScaler?.targetFps ?: 12f
            val decision = decider.decide(trackedObjects, ufoTrajectories, currentFps)

            gesture.moveTo(decision.targetX, decision.urgencyMs)

            val statusText = when {
                decision.isCollecting -> "${getString(R.string.status_collecting)} X:${decision.targetX}"
                decision.priority == com.assistgoat.models.ThreatPriority.CRITICAL ->
                    "DODGE X:${decision.targetX}"
                decision.priority == com.assistgoat.models.ThreatPriority.HIGH ->
                    "AVOID X:${decision.targetX}"
                else -> "OK X:${decision.targetX}"
            }
            overlayManager?.updateStatus(statusText)

            frameCount++

        } finally {
            image.close()
        }
    }

    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap? {
        val planes = image.planes
        if (planes.isEmpty()) return null

        val buffer: ByteBuffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * width

        val bitmapWidth = if (rowPadding > 0) width + rowPadding / pixelStride else width

        try {
            val bitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)

            return if (rowPadding > 0) {
                Bitmap.createBitmap(bitmap, 0, 0, width, height).also {
                    bitmap.recycle()
                }
            } else {
                bitmap
            }
        } catch (e: OutOfMemoryError) {
            return null
        } catch (_: Exception) {
            return null
        }
    }

    private fun startRamMonitor() {
        ramMonitorRunnable = object : Runnable {
            override fun run() {
                if (!isKilled) {
                    checkRamSafety()
                    ramMonitorHandler?.postDelayed(this, 5000)
                }
            }
        }
        ramMonitorHandler.postDelayed(ramMonitorRunnable!!, 5000)
    }

    private fun checkRamSafety(): Boolean {
        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val maxMb = runtime.maxMemory() / (1024 * 1024)
        val freeMb = maxMb - usedMb

        if (freeMb < RAM_SHUTDOWN_MB) {
            return false
        }

        if (freeMb < RAM_WARNING_MB) {
            adaptiveScaler?.forceThrottle()
        }

        return true
    }

    override fun onKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == android.view.KeyEvent.ACTION_DOWN) {
            emergencyShutdown("Volume Down pressed")
            return true
        }
        return super.onKeyEvent(event)
    }

    private fun emergencyShutdown(reason: String) {
        isKilled = true
        isProcessing = false
        isPaused = true
        gestureController?.emergencyKill()
        stopScreenCapture()
        overlayManager?.updateState(false)
        overlayManager?.updateStatus("STOPPED: $reason")

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AssistGoat STOPPED")
            .setContentText("Reason: $reason. Phone is safe.")
            .setSmallIcon(android.R.drawable.ic_media_pause)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val manager = getSystemService(android.app.NotificationManager::class.java)
        manager.notify(FOREGROUND_NOTIFY_ID + 1, notification)
    }

    private fun stopAssistGoat() {
        isProcessing = false
        isPaused = true
        isKilled = true
        gestureController?.stop()
        stopScreenCapture()
        stopRamMonitor()
        overlayManager?.hide()
        scope.cancel()
        decisionEngine?.reset()
        objectTracker?.reset()
        adaptiveScaler?.reset()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopScreenCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
    }

    private fun stopRamMonitor() {
        ramMonitorRunnable?.let { ramMonitorHandler.removeCallbacks(it) }
        ramMonitorRunnable = null
    }

    private fun cleanup() {
        isProcessing = false
        gestureController?.stop()
        stopScreenCapture()
        stopRamMonitor()
        overlayManager?.hide()
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                android.app.NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(android.app.NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                FOREGROUND_NOTIFY_ID, notification,
                Service.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(FOREGROUND_NOTIFY_ID, notification)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        emergencyShutdown("Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanup()
        scope.cancel()
    }
}
