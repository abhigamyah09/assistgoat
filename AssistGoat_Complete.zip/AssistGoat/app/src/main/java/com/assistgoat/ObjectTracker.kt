package com.assistgoat

import android.graphics.Rect
import android.util.Log
import com.assistgoat.models.GameObject
import com.assistgoat.models.ObjectType
import kotlin.math.abs

class ObjectTracker {

    companion object {
        private const val TAG = "ObjectTracker"
        private const val MAX_HISTORY = 10
        private const val MAX_TRACKED_OBJECTS = 20
        private const val MATCH_DISTANCE = 150
    }

    data class TrackedObject(
        val id: Int,
        val type: ObjectType,
        val positions: MutableList<FramePosition>,
        var lastSeenFrame: Int,
        var isExpired: Boolean = false
    )

    data class FramePosition(
        val centerX: Int,
        val centerY: Int,
        val boundingBox: Rect,
        val frameNumber: Int,
        val timestamp: Long
    )

    private val trackedObjects = mutableListOf<TrackedObject>()
    private var nextId = 0
    private var frameCount = 0

    fun updateFrame(detectedObjects: List<GameObject>, timestamp: Long): List<GameObject> {
        frameCount++
        val matchedIds = mutableSetOf<Int>()

        trackedObjects.forEach { it.isExpired = false }

        for (detected in detectedObjects) {
            val bestMatch = findBestMatch(detected)

            if (bestMatch != null) {
                bestMatch.positions.add(
                    FramePosition(
                        centerX = detected.centerX,
                        centerY = detected.centerY,
                        boundingBox = detected.boundingBox,
                        frameNumber = frameCount,
                        timestamp = timestamp
                    )
                )
                bestMatch.lastSeenFrame = frameCount
                matchedIds.add(bestMatch.id)

                while (bestMatch.positions.size > MAX_HISTORY) {
                    bestMatch.positions.removeAt(0)
                }
            } else {
                if (trackedObjects.size < MAX_TRACKED_OBJECTS) {
                    val newId = nextId++
                    val tracked = TrackedObject(
                        id = newId,
                        type = detected.type,
                        positions = mutableListOf(
                            FramePosition(
                                centerX = detected.centerX,
                                centerY = detected.centerY,
                                boundingBox = detected.boundingBox,
                                frameNumber = frameCount,
                                timestamp = timestamp
                            )
                        ),
                        lastSeenFrame = frameCount
                    )
                    trackedObjects.add(tracked)
                    matchedIds.add(newId)
                }
            }
        }

        for (tracked in trackedObjects) {
            if (tracked.id !in matchedIds) {
                tracked.isExpired = true
            }
        }

        trackedObjects.removeAll {
            it.isExpired && (frameCount - it.lastSeenFrame) > 5
        }

        return detectedObjects.map { detected ->
            val match = trackedObjects.find { tracked ->
                tracked.id in matchedIds &&
                tracked.type == detected.type &&
                tracked.positions.last().centerX == detected.centerX &&
                tracked.positions.last().centerY == detected.centerY
            }
            if (match != null) {
                detected.copy(trackedId = match.id)
            } else {
                detected
            }
        }
    }

    private fun findBestMatch(detected: GameObject): TrackedObject? {
        var bestMatch: TrackedObject? = null
        var bestDistance = MATCH_DISTANCE

        for (tracked in trackedObjects) {
            if (tracked.isExpired) continue
            if (tracked.type != detected.type) continue

            val lastPos = tracked.positions.last()
            val dx = abs(lastPos.centerX - detected.centerX)
            val dy = abs(lastPos.centerY - detected.centerY)
            val distance = dx + dy

            if (distance < bestDistance) {
                bestDistance = distance
                bestMatch = tracked
            }
        }

        return bestMatch
    }

    fun getPositionHistory(tracked: TrackedObject): List<FramePosition> {
        return tracked.positions
    }

    fun getActiveUFOs(): List<TrackedObject> {
        return trackedObjects.filter {
            it.type == ObjectType.UFO && !it.isExpired
        }
    }

    fun reset() {
        trackedObjects.clear()
        nextId = 0
        frameCount = 0
    }
}
