package com.assistgoat

import android.util.Log
import com.assistgoat.models.Trajectory
import kotlin.math.abs

class TrajectoryPredictor(
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "TrajectoryPredictor"
        private const val MIN_VELOCITY_FRAMES = 3
        private const val PLAYER_Y_RATIO = 0.82f
        private const val THREAT_SPEED_THRESHOLD = 0.5f
    }

    private val playerY: Int = (screenHeight * PLAYER_Y_RATIO).toInt()
    private const val PLAYER_HALF_WIDTH = 40

    var playerCenterX: Int = screenWidth / 2

    fun predictTrajectory(positions: List<ObjectTracker.FramePosition>): Trajectory? {
        if (positions.size < MIN_VELOCITY_FRAMES) return null

        val recentPositions = positions.takeLast(MIN_VELOCITY_FRAMES)
        val first = recentPositions.first()
        val last = recentPositions.last()

        val frameDelta = (last.frameNumber - first.frameNumber).toFloat()
        if (frameDelta == 0f) return null

        val vx = (last.centerX - first.centerX) / frameDelta
        val vy = (last.centerY - first.centerY) / frameDelta

        if (vy < THREAT_SPEED_THRESHOLD) return null
        if (vy <= 0) return null

        val currentY = last.centerY.toFloat()
        val currentX = last.centerX.toFloat()

        val timeToReachPlayer = (playerY - currentY) / vy
        if (timeToReachPlayer < 0) return null

        val predictedX = currentX + vx * timeToReachPlayer
        val clampedX = predictedX.coerceIn(0f, screenWidth.toFloat()).toInt()

        val willHitPlayer = abs(clampedX - playerCenterX) < PLAYER_HALF_WIDTH * 2

        val frameConfidence = (recentPositions.size.toFloat() / MIN_VELOCITY_FRAMES).coerceIn(0.3f, 1.0f)

        var consistentFrames = 0
        for (i in 1 until recentPositions.size) {
            val frameDx = (recentPositions[i].centerX - recentPositions[i - 1].centerX).toFloat()
            val frameDy = (recentPositions[i].centerY - recentPositions[i - 1].centerY).toFloat()
            if (abs(frameDx - vx) < 5f && abs(frameDy - vy) < 5f) consistentFrames++
        }
        val consistencyConfidence = if (recentPositions.size > 1) {
            consistentFrames.toFloat() / (recentPositions.size - 1)
        } else 0.5f

        val totalConfidence = frameConfidence * 0.4f + consistencyConfidence * 0.6f

        return Trajectory(
            objectId = 0,
            velocityX = vx,
            velocityY = vy,
            predictedLandingX = clampedX,
            confidence = totalConfidence,
            willHitPlayer = willHitPlayer
        )
    }
}
