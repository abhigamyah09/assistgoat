package com.assistgoat

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.util.Log
import com.assistgoat.models.GameObject
import com.assistgoat.models.ObjectType
import kotlin.math.abs

class DetectionEngine(
    private val screenWidth: Int,
    private val screenHeight: Int,
    scanStep: Int = 4
) {

    companion object {
        private const val TAG = "DetectionEngine"
        private const val MIN_OBJECT_WIDTH = 8
        private const val MIN_OBJECT_HEIGHT = 8
        private const val ROI_BOTTOM_PERCENT = 0.95f
        private const val GRID_CELL_SIZE = 12
        private const val MIN_CLUSTER_SIZE = 5
        private const val MAX_CLUSTER_SIZE = 600
    }

    var scanStep: Int = scanStep
        set(value) {
            field = value.coerceIn(2, 8)
        }

    var scanTopRatio: Float = 0.12f
        set(value) {
            field = value.coerceIn(0.05f, 0.80f)
        }

    private data class HSVRange(
        val minH: Float, val maxH: Float,
        val minS: Float, val maxS: Float,
        val minV: Float, val maxV: Float
    )

    private val meteorRange = HSVRange(5f, 30f, 160f, 255f, 120f, 255f)
    private val ufoRange = HSVRange(190f, 230f, 100f, 255f, 80f, 220f)
    private val phoneRange = HSVRange(270f, 310f, 60f, 180f, 140f, 255f)
    private val starRange = HSVRange(0f, 360f, 0f, 50f, 200f, 255f)
    private val playerRange = HSVRange(310f, 345f, 120f, 255f, 100f, 255f)

    private val roiBottom: Int = (screenHeight * ROI_BOTTOM_PERCENT).toInt()
    private val playerScanTop: Int = (screenHeight * 0.75f).toInt()

    private val hsvBuffer = FloatArray(3)

    private var reusablePixels: IntArray? = null
    private var reusablePixelsSize: Int = 0

    private var backgroundPixels: IntArray? = null
    private var backgroundWidth: Int = 0
    private var backgroundHeight: Int = 0

    fun captureBackground(bitmap: Bitmap) {
        backgroundWidth = bitmap.width
        backgroundHeight = bitmap.height
        backgroundPixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(backgroundPixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
    }

    fun detectFrame(bitmap: Bitmap): List<GameObject> {
        val width = bitmap.width
        val height = bitmap.height

        if (backgroundPixels != null && (backgroundWidth != width || backgroundHeight != height)) {
            backgroundPixels = null
        }

        val scaledRoiTop = (scanTopRatio * height / screenHeight).toInt()
        val scaledRoiBottom = (roiBottom * height / screenHeight).toInt()
        val scaledPlayerTop = (playerScanTop * height / screenHeight).toInt()

        val neededSize = width * height
        if (reusablePixels == null || reusablePixelsSize < neededSize) {
            reusablePixels = IntArray(neededSize)
            reusablePixelsSize = neededSize
        }
        val pixels = reusablePixels!!
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val meteorGrid = SpatialGrid(GRID_CELL_SIZE)
        val ufoGrid = SpatialGrid(GRID_CELL_SIZE)
        val phoneGrid = SpatialGrid(GRID_CELL_SIZE)
        val starGrid = SpatialGrid(GRID_CELL_SIZE)
        val playerGrid = SpatialGrid(GRID_CELL_SIZE)

        for (y in scaledRoiTop until scaledRoiBottom step scanStep) {
            for (x in 0 until width step scanStep) {
                val idx = y * width + x
                val pixel = pixels[idx]

                if (backgroundPixels != null && idx < backgroundPixels!!.size) {
                    if (isSimilarPixel(pixel, backgroundPixels!![idx])) continue
                }

                Color.colorToHSV(pixel, hsvBuffer)
                val h = hsvBuffer[0]
                val s = hsvBuffer[1] * 255
                val v = hsvBuffer[2] * 255

                when {
                    isInRange(h, s, v, meteorRange) -> meteorGrid.add(x, y)
                    isInRange(h, s, v, ufoRange) -> ufoGrid.add(x, y)
                    isInRange(h, s, v, phoneRange) -> phoneGrid.add(x, y)
                    isInRange(h, s, v, starRange) -> starGrid.add(x, y)
                }
            }
        }

        for (y in scaledPlayerTop until scaledRoiBottom step scanStep) {
            for (x in 0 until width step scanStep) {
                val idx = y * width + x
                Color.colorToHSV(pixels[idx], hsvBuffer)
                if (isInRange(hsvBuffer[0], hsvBuffer[1] * 255, hsvBuffer[2] * 255, playerRange)) {
                    playerGrid.add(x, y)
                }
            }
        }

        val objects = mutableListOf<GameObject>()
        objects.addAll(gridToObjects(meteorGrid, ObjectType.METEOR, width, height))
        objects.addAll(gridToObjects(ufoGrid, ObjectType.UFO, width, height))
        objects.addAll(gridToObjects(phoneGrid, ObjectType.PHONE, width, height))
        objects.addAll(gridToObjects(starGrid, ObjectType.STAR, width, height))
        objects.addAll(gridToObjects(playerGrid, ObjectType.PLAYER, width, height))

        return objects
    }

    private class SpatialGrid(private val cellSize: Int) {
        private val cells = mutableMapOf<Long, MutableList<Pair<Int, Int>>>()
        private val allPixels = mutableListOf<Pair<Int, Int>>()

        fun add(x: Int, y: Int) {
            if (allPixels.size >= MAX_CLUSTER_SIZE * 5) return
            allPixels.add(x to y)
            val key = cellKey(x, y)
            cells.getOrPut(key) { mutableListOf() }.add(x to y)
        }

        private fun cellKey(x: Int, y: Int): Long {
            val cx = x / cellSize
            val cy = y / cellSize
            return (cx.toLong() shl 32) or (cy.toLong() and 0xFFFFFFFFL)
        }

        fun getClusters(): List<List<Pair<Int, Int>>> {
            if (allPixels.isEmpty()) return emptyList()
            val visited = mutableSetOf<Pair<Int, Int>>()
            val clusters = mutableListOf<List<Pair<Int, Int>>>()

            for (pixel in allPixels) {
                if (pixel in visited) continue

                val cluster = mutableListOf<Pair<Int, Int>>()
                val stack = ArrayDeque<Pair<Int, Int>>()
                stack.add(pixel)
                visited.add(pixel)

                while (stack.isNotEmpty()) {
                    val current = stack.removeLast()
                    cluster.add(current)
                    if (cluster.size >= MAX_CLUSTER_SIZE) break

                    val cx = current.first / cellSize
                    val cy = current.second / cellSize

                    for (dx in -1..1) {
                        for (dy in -1..1) {
                            val neighborKey = ((cx + dx).toLong() shl 32) or
                                    (((cy + dy).toLong()) and 0xFFFFFFFFL)
                            val neighborCell = cells[neighborKey] ?: continue
                            for (neighbor in neighborCell) {
                                if (neighbor !in visited) {
                                    visited.add(neighbor)
                                    stack.add(neighbor)
                                }
                            }
                        }
                    }
                }

                if (cluster.size >= MIN_CLUSTER_SIZE) {
                    clusters.add(cluster)
                }
            }

            return clusters
        }

        fun count(): Int = allPixels.size
    }

    private fun gridToObjects(
        grid: SpatialGrid, type: ObjectType,
        imageWidth: Int, imageHeight: Int
    ): List<GameObject> {
        val clusters = grid.getClusters()
        val objects = mutableListOf<GameObject>()

        for (cluster in clusters) {
            var minX = Int.MAX_VALUE
            var maxX = Int.MIN_VALUE
            var minY = Int.MAX_VALUE
            var maxY = Int.MIN_VALUE

            for ((px, py) in cluster) {
                if (px < minX) minX = px
                if (px > maxX) maxX = px
                if (py < minY) minY = py
                if (py > maxY) maxY = py
            }

            val objWidth = maxX - minX
            val objHeight = maxY - minY

            if (objWidth >= MIN_OBJECT_WIDTH || objHeight >= MIN_OBJECT_HEIGHT) {
                val scaleX = screenWidth.toFloat() / imageWidth
                val scaleY = screenHeight.toFloat() / imageHeight

                objects.add(
                    GameObject(
                        type = type,
                        boundingBox = Rect(
                            (minX * scaleX).toInt(),
                            (minY * scaleY).toInt(),
                            (maxX * scaleX).toInt(),
                            (maxY * scaleY).toInt()
                        ),
                        centerX = ((minX + maxX) / 2 * scaleX).toInt(),
                        centerY = ((minY + maxY) / 2 * scaleY).toInt(),
                        width = (objWidth * scaleX).toInt(),
                        height = (objHeight * scaleY).toInt()
                    )
                )
            }
        }

        return objects
    }

    private fun isInRange(h: Float, s: Float, v: Float, range: HSVRange): Boolean {
        val inHue = if (range.minH > range.maxH) {
            h >= range.minH || h <= range.maxH
        } else {
            h in range.minH..range.maxH
        }
        return inHue && s in range.minS..range.maxS && v in range.minV..range.maxV
    }

    private fun isSimilarPixel(p1: Int, p2: Int): Boolean {
        val dr = abs(Color.red(p1) - Color.red(p2))
        val dg = abs(Color.green(p1) - Color.green(p2))
        val db = abs(Color.blue(p1) - Color.blue(p2))
        return dr < 15 && dg < 15 && db < 15
    }
}
