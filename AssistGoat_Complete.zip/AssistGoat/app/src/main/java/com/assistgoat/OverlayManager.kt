package com.assistgoat

import android.content.Context
import android.content.ContextWrapper
import android.graphics.PixelFormat
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import com.assistgoat.R
import kotlin.math.abs

class OverlayManager(
    private val context: Context,
    private val onToggle: (Boolean) -> Unit
) {

    companion object {
        private const val TAG = "OverlayManager"
        private const val OVERLAY_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        private const val LONG_PRESS_MS = 2000L
    }

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var statusTextView: TextView? = null
    private var mainButton: ImageView? = null
    private var isShowing = false

    @Volatile
    var isBotActive: Boolean = false
        private set

    private var pendingConfirmAction: (() -> Unit)? = null
    private var lastTapTime = 0L

    fun show() {
        if (isShowing) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            OVERLAY_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 16
        params.y = 200

        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }

        statusTextView = TextView(context).apply {
            text = context.getString(R.string.status_stopped)
            setTextColor(0xFFFF1744.toInt())
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(4, 2, 4, 2)
        }
        layout.addView(statusTextView)

        val hintView = TextView(context).apply {
            text = "Long press to activate"
            textSize = 9f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
        }
        layout.addView(hintView)

        mainButton = ImageView(context).apply {
            setImageResource(android.R.drawable.ic_media_pause)
            setBackgroundResource(R.drawable.overlay_button_bg)
            setPadding(8, 8, 8, 8)
            layoutParams = LinearLayout.LayoutParams(100, 100)
            tag = false

            setOnTouchListener(object : View.OnTouchListener {
                private var initialRawX = 0f
                private var initialRawY = 0f
                private var initialParamX = 0
                private var initialParamY = 0
                private var isDragging = false
                private var longPressRunnable: Runnable? = null
                private var handler = android.os.Handler(android.os.Looper.getMainLooper())
                private var hasTriggeredLongPress = false

                override fun onTouch(view: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialRawX = event.rawX
                            initialRawY = event.rawY
                            initialParamX = params.x
                            initialParamY = params.y
                            isDragging = false
                            hasTriggeredLongPress = false

                            longPressRunnable = Runnable {
                                hasTriggeredLongPress = true
                                vibrateIfNeeded()
                                onLongPressActivated()
                            }
                            handler.postDelayed(longPressRunnable!!, LONG_PRESS_MS)
                        }

                        MotionEvent.ACTION_MOVE -> {
                            val dx = event.rawX - initialRawX
                            val dy = event.rawY - initialRawY

                            if (abs(dx) > 10 || abs(dy) > 10) {
                                isDragging = true
                                longPressRunnable?.let { handler.removeCallbacks(it) }
                            }

                            if (isDragging) {
                                params.x = initialParamX + dx.toInt()
                                params.y = initialParamY + dy.toInt()
                                try {
                                    windowManager.updateViewLayout(overlayView, params)
                                } catch (_: Exception) {}
                            }
                        }

                        MotionEvent.ACTION_UP -> {
                            longPressRunnable?.let { handler.removeCallbacks(it) }
                            if (!isDragging && !hasTriggeredLongPress) {
                                onTapToggle()
                            }
                        }

                        MotionEvent.ACTION_CANCEL -> {
                            longPressRunnable?.let { handler.removeCallbacks(it) }
                        }
                    }
                    return true
                }
            })
        }
        layout.addView(mainButton)

        try {
            windowManager.addView(layout, params)
            overlayView = layout
            isShowing = true
        } catch (_: Exception) {}
    }

    private fun onLongPressActivated() {
        if (isBotActive) {
            showConfirmDialog(
                title = "Stop AssistGoat?",
                message = "Are you sure you want to stop the bot?",
                onConfirm = {
                    isBotActive = false
                    updateButtonState(false)
                    onToggle(false)
                    Toast.makeText(context, "Bot STOPPED", Toast.LENGTH_SHORT).show()
                },
                onCancel = {}
            )
        } else {
            showConfirmDialog(
                title = "Start AssistGoat?",
                message = "The bot will start playing automatically.\n\nPress Volume DOWN anytime to EMERGENCY STOP.\n\nContinue?",
                onConfirm = {
                    isBotActive = true
                    updateButtonState(true)
                    onToggle(true)
                    Toast.makeText(context, "Bot ACTIVATED!", Toast.LENGTH_SHORT).show()
                },
                onCancel = {}
            )
        }
    }

    private fun onTapToggle() {
        if (!isBotActive) {
            Toast.makeText(context, "Long press to activate", Toast.LENGTH_SHORT).show()
            return
        }
        val currentState = mainButton?.tag as? Boolean ?: false
        updateButtonState(!currentState)
        onToggle(!currentState)
    }

    private fun showConfirmDialog(
        title: String,
        message: String,
        onConfirm: () -> Unit,
        onCancel: () -> Unit
    ) {
        val activityContext = findActivityContext()

        if (activityContext != null) {
            try {
                AlertDialog.Builder(activityContext)
                    .setTitle(title)
                    .setMessage(message)
                    .setPositiveButton("YES, I'm sure") { _, _ -> onConfirm() }
                    .setNegativeButton("Cancel") { _, _ -> onCancel() }
                    .setCancelable(true)
                    .show()
                return
            } catch (_: Exception) {}
        }

        val now = System.currentTimeMillis()
        if (pendingConfirmAction != null && (now - lastTapTime) < 3000) {
            pendingConfirmAction = null
            Toast.makeText(context, "Confirmed!", Toast.LENGTH_SHORT).show()
            onConfirm()
        } else {
            pendingConfirmAction = onConfirm
            lastTapTime = now
            Toast.makeText(context, "$title - Tap AGAIN within 3s to confirm", Toast.LENGTH_LONG).show()
        }
    }

    private fun findActivityContext(): Context? {
        var ctx = context
        while (ctx is ContextWrapper) {
            if (ctx is AppCompatActivity || ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    private fun vibrateIfNeeded() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (vibrator?.hasVibrator() == true) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(android.os.VibrationEffect.createOneShot(50, 100))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(50)
                }
            }
        } catch (_: Exception) {}
    }

    private fun updateButtonState(isActive: Boolean) {
        mainButton?.tag = isActive
        mainButton?.setImageResource(
            if (isActive) android.R.drawable.ic_media_play
            else android.R.drawable.ic_media_pause
        )
        statusTextView?.text = if (isActive) {
            context.getString(R.string.status_active)
        } else {
            context.getString(R.string.status_stopped)
        }
        statusTextView?.setTextColor(
            if (isActive) 0xFF00E676.toInt() else 0xFFFF1744.toInt()
        )
    }

    fun updateState(isActive: Boolean) {
        isBotActive = isActive
        updateButtonState(isActive)
    }

    fun updateStatus(status: String) {
        statusTextView?.text = status
    }

    fun hide() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
        isShowing = false
        isBotActive = false
    }

    fun isVisible(): Boolean = isShowing
}
