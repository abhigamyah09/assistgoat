package com.assistgoat

import android.util.Log
import com.assistgoat.models.GameObject
import com.assistgoat.models.MovementDecision
import com.assistgoat.models.ObjectType
import com.assistgoat.models.ThreatPriority
import com.assistgoat.models.Trajectory
import kotlin.math.abs

class DecisionEngine(
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "DecisionEngine"
        private const val THREAT_X_MARGIN = 50
        private const val COLLECTIBLE_X_MARGIN = 15
        private const val PLAYER_SAFE_MARGIN = 30
        private const val MOVE_URGENCY_FAST = 150L
        private const val MOVE_URGENCY_NORMAL = 250L
        private const val PLAYER_Y_RATIO = 0.82f
    }

    private val playerY: Int = (screenHeight * PLAYER_Y_RATIO).toInt()

    private var lastKnownPlayerX: Int = screenWidth / 2
    private var lastKnownPlayerTime: Long = 0
    private var playerPositionLost: Boolean = false
    private var currentScore: Int = 0

    fun decide(
        objects: List<GameObject>,
        ufoTrajectories: Map<Int, Trajectory>,
        currentFps: Float
    ): MovementDecision {
        val playerX = findPlayerX(objects)
        updatePlayerMemory(playerX)

        val threatZones = calculateThreatZones(objects, ufoTrajectories, currentFps)

        if (threatZones.isEmpty()) {
            val collectibleDecision = findBestCollectible(objects, playerX, emptyList())
            if (collectibleDecision != null) return collectibleDecision
            return MovementDecision(
                targetX = playerX,
                priority = ThreatPriority.SAFE,
                reason = "No threats or collectibles nearby",
                urgencyMs = MOVE_URGENCY_NORMAL
            )
        }

        val safeX = findSafestX(playerX, threatZones)

        val safeCollectible = findBestCollectible(objects, playerX, threatZones)
        if (safeCollectible != null && isSafeToCollect(safeCollectible.targetX, threatZones)) {
            if (isOnTheWay(playerX, safeCollectible.targetX, safeX)) {
                return safeCollectible.copy(
                    priority = determineThreatPriority(threatZones, playerX, currentFps)
                )
            }
            return MovementDecision(
                targetX = safeX,
                priority = determineThreatPriority(threatZones, playerX, currentFps),
                reason = "Collecting safe item while dodging",
                isCollecting = true,
                urgencyMs = MOVE_URGENCY_FAST
            )
        }

        return MovementDecision(
            targetX = safeX,
            priority = determineThreatPriority(threatZones, playerX, currentFps),
            reason = buildThreatReason(threatZones),
            urgencyMs = MOVE_URGENCY_FAST
        )
    }

    private fun findPlayerX(objects: List<GameObject>): Int {
        val player = objects.filter { it.type == ObjectType.PLAYER }

        return if (player.isNotEmpty()) {
            val avgX = player.map { it.centerX }.average().toInt()
            playerPositionLost = false
            lastKnownPlayerX = avgX
            lastKnownPlayerTime = System.currentTimeMillis()
            avgX
        } else {
            playerPositionLost = true
            val timeSince = System.currentTimeMillis() - lastKnownPlayerTime

            if (timeSince > 500) {
                val center = screenWidth / 2
                val blendFactor = minOf(1f, (timeSince - 500).toFloat() / 1000f)
                return (lastKnownPlayerX * (1 - blendFactor) + center * blendFactor).toInt()
            }

            lastKnownPlayerX
        }
    }

    private fun updatePlayerMemory(playerX: Int) {
        if (!playerPositionLost) {
            lastKnownPlayerX = playerX
            lastKnownPlayerTime = System.currentTimeMillis()
        }
    }

    private fun calculateThreatZones(
        objects: List<GameObject>,
        ufoTrajectories: Map<Int, Trajectory>,
        currentFps: Float
    ): List<ThreatZone> {
        val zones = mutableListOf<ThreatZone>()

        for (obj in objects.filter { it.type == ObjectType.METEOR }) {
            if (obj.centerY < playerY) {
                zones.add(
                    ThreatZone(
                        centerX = obj.centerX,
                        halfWidth = THREAT_X_MARGIN,
                        type = ObjectType.METEOR,
                        urgency = calculateUrgency(obj.centerY, currentFps),
                        trackedId = obj.trackedId
                    )
                )
            }
        }

        for (obj in objects.filter { it.type == ObjectType.UFO }) {
            val trajectory = ufoTrajectories[obj.trackedId]
            if (trajectory != null && trajectory.confidence > 0.4f) {
                zones.add(
                    ThreatZone(
                        centerX = trajectory.predictedLandingX,
                        halfWidth = THREAT_X_MARGIN + 10,
                        type = ObjectType.UFO,
                        urgency = calculateUrgency(obj.centerY, currentFps),
                        trackedId = obj.trackedId
                    )
                )
            } else {
                zones.add(
                    ThreatZone(
                        centerX = obj.centerX,
                        halfWidth = THREAT_X_MARGIN + 30,
                        type = ObjectType.UFO,
                        urgency = calculateUrgency(obj.centerY, currentFps),
                        trackedId = obj.trackedId
                    )
                )
            }
        }

        return zones.sortedBy { it.urgency }
    }

    private fun calculateUrgency(threatY: Int, fps: Float): Float {
        val distanceToPlayer = playerY - threatY
        return if (fps > 0) distanceToPlayer / fps else Float.MAX_VALUE
    }

    private fun findSafestX(playerX: Int, threatZones: List<ThreatZone>): Int {
        val candidates = mutableListOf<Int>()
        candidates.add(playerX)
        candidates.add(PLAYER_SAFE_MARGIN)
        candidates.add(screenWidth - PLAYER_SAFE_MARGIN)

        for (i in 0 until threatZones.size - 1) {
            val midX = (threatZones[i].centerX + threatZones[i + 1].centerX) / 2
            candidates.add(midX)
        }

        for (x in PLAYER_SAFE_MARGIN..(screenWidth - PLAYER_SAFE_MARGIN) step 200) {
            candidates.add(x)
        }

        var bestX = playerX
        var bestScore = Float.NEGATIVE_INFINITY

        for (candidate in candidates) {
            val score = evaluatePosition(candidate, threatZones, playerX)
            if (score > bestScore) {
                bestScore = score
                bestX = candidate
            }
        }

        return bestX.coerceIn(PLAYER_SAFE_MARGIN, screenWidth - PLAYER_SAFE_MARGIN)
    }

    private fun evaluatePosition(x: Int, threatZones: List<ThreatZone>, playerX: Int): Float {
        var score = 0f

        for (zone in threatZones) {
            val dist = abs(x - zone.centerX)
            if (dist < zone.halfWidth) {
                score -= 1000f / (zone.halfWidth - dist + 1)
            } else {
                score += dist.toFloat() / zone.halfWidth
            }

            if (zone.urgency < 10) {
                if (dist >= zone.halfWidth) score += 50f
            }
        }

        val moveDistance = abs(x - playerX)
        if (moveDistance > screenWidth / 3) {
            score -= moveDistance * 0.1f
        }

        if (x < PLAYER_SAFE_MARGIN * 2 || x > screenWidth - PLAYER_SAFE_MARGIN * 2) {
            score -= 20f
        }

        return score
    }

    private fun isSafeToCollect(collectibleX: Int, threatZones: List<ThreatZone>): Boolean {
        for (zone in threatZones) {
            if (abs(collectibleX - zone.centerX) < zone.halfWidth + COLLECTIBLE_X_MARGIN) {
                return false
            }
        }
        return true
    }

    private fun findBestCollectible(
        objects: List<GameObject>,
        playerX: Int,
        threatZones: List<ThreatZone>
    ): MovementDecision? {
        val collectibles = objects.filter {
            it.type == ObjectType.PHONE || it.type == ObjectType.STAR
        }.filter {
            it.centerY < playerY
        }.filter {
            abs(it.centerX - playerX) < screenWidth / 2
        }

        if (collectibles.isEmpty()) return null

        val sorted = collectibles.sortedWith(
            compareByDescending<GameObject> {
                when (it.type) {
                    ObjectType.PHONE -> 2
                    ObjectType.STAR -> 1
                    else -> 0
                }
            }.thenBy { abs(it.centerX - playerX) }
        )

        val target = sorted.first()
        return MovementDecision(
            targetX = target.centerX,
            priority = ThreatPriority.LOW,
            reason = "Collecting ${target.type.name} at X=${target.centerX}",
            isCollecting = true,
            urgencyMs = MOVE_URGENCY_NORMAL
        )
    }

    private fun isOnTheWay(fromX: Int, viaX: Int, toX: Int): Boolean {
        return when {
            toX > fromX -> viaX in fromX..toX
            toX < fromX -> viaX in toX..fromX
            else -> false
        }
    }

    private fun determineThreatPriority(
        threatZones: List<ThreatZone>,
        playerX: Int,
        currentFps: Float
    ): ThreatPriority {
        if (threatZones.isEmpty()) return ThreatPriority.SAFE

        for (zone in threatZones) {
            if (abs(playerX - zone.centerX) < zone.halfWidth) {
                return when {
                    zone.urgency < 5 -> ThreatPriority.CRITICAL
                    zone.urgency < 15 -> ThreatPriority.HIGH
                    else -> ThreatPriority.MEDIUM
                }
            }
        }

        val closestUrgency = threatZones.minOf { it.urgency }
        return when {
            closestUrgency < 10 -> ThreatPriority.HIGH
            closestUrgency < 25 -> ThreatPriority.MEDIUM
            else -> ThreatPriority.LOW
        }
    }

    private fun buildThreatReason(threatZones: List<ThreatZone>): String {
        val meteors = threatZones.count { it.type == ObjectType.METEOR }
        val ufos = threatZones.count { it.type == ObjectType.UFO }
        return buildString {
            if (meteors > 0) append("Dodging $meteors meteor${if (meteors > 1) "s" else ""}")
            if (meteors > 0 && ufos > 0) append(" + ")
            if (ufos > 0) append("Avoiding $ufos UFO${if (ufos > 1) "s" else ""}")
        }
    }

    fun updateScore(newScore: Int) {
        currentScore = newScore
    }

    fun getAdaptiveScanTopPercent(): Float {
        return when {
            currentScore < 5 -> 0.60f
            currentScore < 15 -> 0.45f
            else -> 0.30f
        }
    }

    fun getPlayerX(): Int = lastKnownPlayerX

    fun reset() {
        lastKnownPlayerX = screenWidth / 2
        lastKnownPlayerTime = 0
        playerPositionLost = false
        currentScore = 0
    }

    private data class ThreatZone(
        val centerX: Int,
        val halfWidth: Int,
        val type: ObjectType,
        val urgency: Float,
        val trackedId: Int
    )
}
